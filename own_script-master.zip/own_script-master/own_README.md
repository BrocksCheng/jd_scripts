jd_818 ✅ jd_818.yml
jd_xtg ✅ jd_xtg.yml
京豆变动通知(jd_bean_change.js) ✅ jd_bean_change.yml
京东多合一签到(jd_bean_sign.js) ✅ jd_bean_sign.yml 【可N个京东账号，Node.js专用，核心脚本是JD_DailyBonus.js， IOS软件用户请使用NobyDa的 JD_DailyBonus.js 】
京小超兑换奖品(jd_blueCoin.js) ✅ jd_blueCoin.yml
摇京豆(jd_club_lottery.js) ✅ jd_club_lottery.yml
京东水果(jd_fruit.js) ✅ jd_fruit.yml
宠汪汪单独喂食(jd_joy_feedPets.js) ✅ jd_joy_feedPets.yml
宠汪汪兑换奖品(jd_joy_reward.js) ✅ jd_joy_reward.yml
宠汪汪偷好友狗粮与积分(jd_joy_steal.js) ✅ jd_joy_steal.yml
宠汪汪(jd_joy.js) ✅ jd_joy.yml
摇钱树(jd_moneyTree.js) ✅ jd_moneyTree.yml
东东萌宠(jd_pet.js) ✅ jd_pet.yml
种豆得豆(jd_plantBean.js) ✅ jd_plantBean.yml
全名开红包(jd_redPacket.js) ✅ jd_redPacket.yml
进店领豆(jd_shop.js) ✅ jd_shop.yml
天天加速(jd_speed.js) ✅ jd_speed.yml
京小超(jd_superMarket.js) ✅ jd_superMarket.yml
取关京东店铺和商品(jd_unsubscribe.js) ✅ jd_unsubscribe.yml
jd_rankingList ✅ jd_rankingList.yml
jd_lotteryMachine ✅ jd_lotteryMachine.yml
jd_daily_egg ✅ jd_daily_egg.yml
jd_collectProduceScore ✅ jd_collectProduceScore.yml
jd_pigPet ✅ jd_pigPet.yml 20201112


jd_dreamFactory ❎
JD_extra_cookie ❎
jd_mohe ❎


宠汪汪聚宝盆辅助脚本(jd_petTreasureBox.js) ✅🚦
宠汪汪强制为好友助力(刷好友)(jd_joy_help.js) ✅🚦
宠汪汪赛跑助力(jd_joy_run.js) ✅🚦


